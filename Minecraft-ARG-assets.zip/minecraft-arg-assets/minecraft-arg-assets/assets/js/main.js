const issues = [
{ id: 43, text: "World continues past bottom. Possible infection from A.BENEATH" },
{ id: 44, text: "Entities behave strangely near edges of map" },
{ id: 45, text: "Corrupted items appear in inventory [SIGIL HIDDEN]" }
];


const list = document.getElementById('issues');
issues.forEach(issue => {
const li = document.createElement('li');
li.textContent = `Issue #${issue.id}: ${issue.text}`;
list.appendChild(li);
});